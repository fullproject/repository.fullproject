import urllib
import re
import urllib2
import xbmcplugin
import xbmcgui
import xbmc
import xbmcaddon
import os
import time
import zipfile
import zlib
import gzip
import shutil
import binascii
import extract
import skindefault
import plugintools
if 64 - 64: i11iIiiIii
OO0o = xbmcaddon . Addon ( ) . getAddonInfo ( 'id' )
Oo0Ooo = xbmcaddon . Addon ( id = OO0o )
O0O0OO0O0O0 = Oo0Ooo . getAddonInfo ( 'name' )
iiiii = xbmc . translatePath ( os . path . join ( 'special://home/addons' , OO0o ) )
ooo0OO = xbmcgui . Dialog ( )
II1 = xbmcgui . DialogProgress ( )
O00ooooo00 = xbmc . translatePath ( os . path . join ( 'special://home' , '' ) )
I1IiiI = xbmc . translatePath ( 'special://home/' )
IIi1IiiiI1Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/packages' ) )
I11i11Ii = xbmc . translatePath ( os . path . join ( 'special://home/addons/packages' , 'hotrod.18.zip' ) )
oO00oOo = [ OO0o , IIi1IiiiI1Ii ]
OOOo0 = os . path . join ( I1IiiI , 'userdata' )
Oooo000o = os . path . join ( OOOo0 , 'addon_data' , OO0o )
IiIi11iIIi1Ii = os . path . join ( Oooo000o , 'wizard.log' )
Oo0O = Oo0Ooo . getSetting ( 'addon_debug' )
IiI = Oo0Ooo . getSetting ( 'debuglevel' )
ooOo = Oo0Ooo . getSetting ( 'debuglevel' )
Oo = os . path . join ( 'special://home/addons/' , OO0o , 'icon.png' )
urllib . URLopener . version = 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/35.0.1916.153 Safari/537.36 SE 2.X MetaSr 1.0'
o0O = "789ccb28292928b6d2d72f482c2e494dcaccd34bcecfd52f4a2cd78fccab28280871ce0400d2790c56"
def IiiIII111iI ( ) :
 skindefault . SetDefaultSkin ( )
 plugintools . log ( "freshstart.main_list " )
 IiII = xbmcaddon . Addon ( id = OO0o ) . getAddonInfo ( 'path' )
 IiII = xbmc . translatePath ( IiII )
 iI1Ii11111iIi = os . path . join ( IiII , ".." , ".." )
 iI1Ii11111iIi = os . path . abspath ( iI1Ii11111iIi )
 plugintools . log ( "freshstart.main_list xbmcPath=" + iI1Ii11111iIi )
 i1i1II = False
 try :
  for O0oo0OO0 , I1i1iiI1 , iiIIIII1i1iI in os . walk ( iI1Ii11111iIi , topdown = True ) :
   I1i1iiI1 [ : ] = [ o0oO0 for o0oO0 in I1i1iiI1 if o0oO0 not in oO00oOo ]
   for oo00 in iiIIIII1i1iI :
    try : os . remove ( os . path . join ( O0oo0OO0 , oo00 ) )
    except : pass
  for O0oo0OO0 , I1i1iiI1 , iiIIIII1i1iI in os . walk ( iI1Ii11111iIi , topdown = True ) :
   I1i1iiI1 [ : ] = [ o0oO0 for o0oO0 in I1i1iiI1 if o0oO0 not in oO00oOo ]
   for oo00 in I1i1iiI1 :
    if oo00 not in [ "Database" , "userdata" , "temp" , "addons" , "addon_data" ] :
     try : shutil . rmtree ( os . path . join ( O0oo0OO0 , oo00 ) , ignore_errors = True , onerror = None )
     except : pass
 except : pass
def o00 ( timer , title , text , text2 ) :
 Oo0oO0ooo = xbmcgui . DialogProgress ( )
 o0oOoO00o = Oo0oO0ooo . create ( ' ' + title )
 i1 = 0
 oOOoo00O0O = 0
 i1111 = int ( 100 / timer )
 while i1 < timer :
  i1 += 1
  oOOoo00O0O = i1111 * i1
  i11 = str ( ( timer - i1 ) )
  I11 = '[COLOR red][B]' + str ( i11 ) + " segundos" + '[/B][/COLOR]'
  Oo0oO0ooo . update ( oOOoo00O0O , text + I11 , "" , text2 )
  xbmc . sleep ( 1000 )
def Oo0o0000o0o0 ( url , dest , dp = None ) :
 if not dp :
  dp = xbmcgui . DialogProgress ( )
  dp . create ( O0O0OO0O0O0 , "Downloading Content" , ' ' , ' ' )
 dp . update ( 0 )
 oOo0oooo00o = time . time ( )
 urllib . urlretrieve ( url , dest , lambda oO0o0o0ooO0oO , oo0o0O00 , oO : i1iiIIiiI111 ( oO0o0o0ooO0oO , oo0o0O00 , oO , dp , oOo0oooo00o ) )
def i1iiIIiiI111 ( numblocks , blocksize , filesize , dp , start_time ) :
 try :
  oOOoo00O0O = min ( numblocks * blocksize * 100 / filesize , 100 )
  oooOOOOO = float ( numblocks ) * blocksize / ( 1024 * 1024 )
  i1iiIII111ii = numblocks * blocksize / ( time . time ( ) - start_time )
  if i1iiIII111ii > 0 and not oOOoo00O0O == 100 :
   i1iIIi1 = ( filesize - numblocks * blocksize ) / i1iiIII111ii
  else :
   i1iIIi1 = 0
  i1iiIII111ii = i1iiIII111ii / 1024
  ii11iIi1I = 'KB'
  if i1iiIII111ii >= 1024 :
   i1iiIII111ii = i1iiIII111ii / 1024
   ii11iIi1I = 'MB'
  iI111I11I1I1 = float ( filesize ) / ( 1024 * 1024 )
  OOooO0OOoo = '[COLOR=lime][B]Tamanho:[/B][COLOR] [COLOR=red]%.02f[/COLOR][COLOR=lime] MB of[/COLOR] [COLOR=red]%.02f[/COLOR][COLOR=lime] MB[/COLOR]' % ( oooOOOOO , iI111I11I1I1 )
  iIii1 = '[COLOR lime][B]Velocidade:[/B][COLOR] [COLOR=red]%.02f[/COLOR][COLOR=red]%s/s[/COLOR]' % ( i1iiIII111ii , ii11iIi1I )
  iIii1 += '[COLOR=lime][B] ETA:[/B][COLOR] [COLOR=red]%02d:[/COLOR][COLOR=red]%02d[/COLOR]' % divmod ( i1iIIi1 , 60 )
  dp . update ( oOOoo00O0O , '' , OOooO0OOoo , iIii1 )
 except Exception , iIii1 :
  dp . create ( "ERROR Downloading: %s" % str ( iIii1 ) , xbmc . LOGERROR )
  return str ( iIii1 )
 if dp . iscanceled ( ) :
  ooo0OO = xbmcgui . Dialog ( )
  ooo0OO . ok ( O0O0OO0O0O0 , 'Download Cancelado.' , 'Seu sistema encontra-se limpo! Tem que Reiniciar o seu sistema!' )
  shutil . rmtree ( iiiii , ignore_errors = True )
  oOOoO0 ( )
def O0OoO000O0OO ( url ) :
 iiI1IiI = urllib2 . Request ( url )
 iiI1IiI . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3' )
 II = urllib2 . urlopen ( iiI1IiI )
 ooOoOoo0O = II . read ( )
 II . close ( )
 return ooOoOoo0O . replace ( '\r' , '' ) . replace ( '\n' , '' ) . replace ( '\t' , '' )
def oOOoO0 ( ) :
 OooO0 = II11iiii1Ii ( )
 OO0oOoo ( "Force Closing Kodi: Platform[%s]" % str ( II11iiii1Ii ( ) ) , xbmc . LOGNOTICE )
 os . _exit ( 1 )
def II11iiii1Ii ( ) :
 if xbmc . getCondVisibility ( 'system.platform.android' ) : return 'android'
 elif xbmc . getCondVisibility ( 'system.platform.linux' ) : return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.linux.Raspberrypi' ) : return 'linux'
 elif xbmc . getCondVisibility ( 'system.platform.windows' ) : return 'windows'
 elif xbmc . getCondVisibility ( 'system.platform.osx' ) : return 'osx'
 elif xbmc . getCondVisibility ( 'system.platform.atv2' ) : return 'atv2'
 elif xbmc . getCondVisibility ( 'system.platform.ios' ) : return 'ios'
 elif xbmc . getCondVisibility ( 'system.platform.darwin' ) : return 'ios'
def OO0oOoo ( title , message , times = 2000 , icon = Oo ) :
 xbmc . executebuiltin ( 'XBMC.Notification(%s, %s, %s, %s)' % ( title , message , times , icon ) )
def O0o0Oo ( ) :
 II1 = xbmcgui . DialogProgress ( )
 II1 . create ( O0O0OO0O0O0 , 'A restaurar o seu sistema!' )
 time . sleep ( 2 )
 Oo00OOOOO = 1
 O0O = xbmc . getInfoLabel ( 'Network.IPAddress' )
 try :
  O0OoO000O0OO ( 'http://google.com' )
 except :
  Oo00OOOOO = 0
 if O0O == '' or Oo00OOOOO == 0 :
  ooo0OO . ok ( "SEM INTERNET!" , 'Por favor, conecte-se e tente novamente.' , '' , '' )
  return
 else :
  IiiIII111iI ( )
  II1 . create ( O0O0OO0O0O0 , 'Iniciar Download para o seu sistema!' )
  time . sleep ( 2 )
  if not os . path . exists ( IIi1IiiiI1Ii ) : os . makedirs ( IIi1IiiiI1Ii )
  ooOoOoo0O = O0OoO000O0OO ( zlib . decompress ( binascii . unhexlify ( o0O ) ) ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  O00o0OO = re . compile ( 'url="(.+?)"' ) . findall ( ooOoOoo0O )
  I11i1 = O00o0OO [ 0 ] if ( len ( O00o0OO ) > 0 ) else ''
  iIi1ii1I1 = xbmc . translatePath ( os . path . join ( 'special://home/addons/packages' ) )
  II1 = xbmcgui . DialogProgress ( )
  II1 . create ( O0O0OO0O0O0 , 'Espere um pouco.' )
  o0 = os . path . join ( iIi1ii1I1 , 'hotrod.18.zip' )
  I11II1i = xbmc . translatePath ( os . path . join ( 'special://home' ) )
  if os . path . exists ( o0 ) :
   os . remove ( o0 )
  Oo0o0000o0o0 ( I11i1 , o0 , II1 )
 try :
  extract . all ( o0 , I11II1i , II1 )
  time . sleep ( 2 )
  ooo0OO = xbmcgui . Dialog ( )
  shutil . rmtree ( IIi1IiiiI1Ii , ignore_errors = True )
  ooo0OO . ok ( "[COLOR=lime]MUITO IMPORTANTE:[/COLOR]" , 'O complemento atualizado feito desta forma, pode ter que habilitar a skin!' , 'Reiniciar o seu sistema!' )
  oOOoO0 ( )
 except IOError , ( IIIII , ooooooO0oo ) :
  message ( "Failed to open required files" , "Error code is:" , ooooooO0oo )
  return False
def IIiiiiiiIi1I1 ( ) :
 I1IIIii = xbmc . getInfoLabel ( 'System.BuildVersion' )
 oOoOooOo0o0 = float ( I1IIIii [ : 4 ] )
 if oOoOooOo0o0 >= 15.0 and oOoOooOo0o0 <= 17.9 :
  OOOO = exit ( )
 elif oOoOooOo0o0 >= 18.0 and oOoOooOo0o0 <= 18.5 :
  OOOO = O0o0Oo ( )
 elif oOoOooOo0o0 >= 19.0 and oOoOooOo0o0 <= 19.9 :
  OOOO = exit ( )
 else : OOOO = exit ( )
 return OOOO
def exit ( ) :
 ooo0OO = xbmcgui . Dialog ( )
 ooo0OO . ok ( O0O0OO0O0O0 , '[COLOR=lime]MUITO IMPORTANTE:[/COLOR]' , 'O complemento apenas para ser usado em Kodi 18!' , 'Addon vai ser [COLOR=red]apagado![/COLOR]' )
 time . sleep ( 2 )
 shutil . rmtree ( iiiii , ignore_errors = True )
 oOOoO0 ( )
IIiiiiiiIi1I1 ( )
xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) ) # dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
